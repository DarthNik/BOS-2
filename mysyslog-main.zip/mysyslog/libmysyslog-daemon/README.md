## Использование
Запустите демон:
```
sudo systemctl enable --now libmysyslog-daemon.service
```
Демон будет записывать сообщения каждые 5 секунд.