#ifndef LIBMYSYSLOG_JSON_H
#define LIBMYSYSLOG_JSON_H

int log_to_json(const char* msg, int level, const char* path);

#endif // LIBMYSYSLOG_JSON_H