#ifndef LIBMYSYSLOG_TEXT_H
#define LIBMYSYSLOG_TEXT_H

int log_to_text(const char* msg, int level, const char* path);

#endif // LIBMYSYSLOG_TEXT_H